﻿# ==============================================================================
# Kalpten Kaleme - Local Server & Desktop App Launcher
# Supports Windows "Open With" (Birlikte Aç) and Command-Line File Arguments
# 100% SAC-Safe: No dynamic inline C# compilation
# ==============================================================================

param(
    [string]$FilePath = "",
    [switch]$Daemon
)

$candidatePorts = @(52480, 52481, 52482, 52483, 52484)
$port = 52480
$rootDir = $PSScriptRoot
if ([string]::IsNullOrWhiteSpace($rootDir)) {
    $rootDir = Split-Path -Parent $MyInvocation.MyCommand.Path
}
$openFileRecord = Join-Path $rootDir "current_open_file.txt"
$script:allowAutoExit = (-not [bool]$Daemon)

$mimeTypes = @{
    ".html" = "text/html; charset=utf-8"
    ".css"  = "text/css; charset=utf-8"
    ".js"   = "application/javascript; charset=utf-8"
    ".json" = "application/json; charset=utf-8"
    ".png"  = "image/png"
    ".ico"  = "image/x-icon"
    ".jpg"  = "image/jpeg"
    ".jpeg" = "image/jpeg"
    ".svg"  = "image/svg+xml"
    ".pdf"  = "application/pdf"
    ".zip"  = "application/zip"
    ".apk"  = "application/vnd.android.package-archive"
    ".pptx" = "application/vnd.openxmlformats-officedocument.presentationml.presentation"
    ".ppt"  = "application/vnd.ms-powerpoint"
    ".docx" = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    ".txt"  = "text/plain; charset=utf-8"
}

function Find-ChromiumAppBrowser {
    $candidates = New-Object System.Collections.Generic.List[string]
    $pfX86 = ${env:ProgramFiles(x86)}
    $pf = $env:ProgramFiles
    $local = $env:LOCALAPPDATA

    if ($pfX86) { $candidates.Add((Join-Path $pfX86 "Microsoft\Edge\Application\msedge.exe")) }
    if ($pf)    { $candidates.Add((Join-Path $pf "Microsoft\Edge\Application\msedge.exe")) }
    if ($local) { $candidates.Add((Join-Path $local "Microsoft\Edge\Application\msedge.exe")) }
    $candidates.Add("C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe")
    $candidates.Add("C:\Program Files\Microsoft\Edge\Application\msedge.exe")

    if ($pf)    { $candidates.Add((Join-Path $pf "Google\Chrome\Application\chrome.exe")) }
    if ($pfX86) { $candidates.Add((Join-Path $pfX86 "Google\Chrome\Application\chrome.exe")) }
    if ($local) { $candidates.Add((Join-Path $local "Google\Chrome\Application\chrome.exe")) }

    if ($pf)    { $candidates.Add((Join-Path $pf "BraveSoftware\Brave-Browser\Application\brave.exe")) }
    if ($local) { $candidates.Add((Join-Path $local "BraveSoftware\Brave-Browser\Application\brave.exe")) }

    foreach ($exeName in @("msedge.exe", "chrome.exe", "brave.exe")) {
        foreach ($hive in @("HKLM:", "HKCU:")) {
            try {
                $v = (Get-ItemProperty -Path "$hive\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\$exeName" -ErrorAction SilentlyContinue)."(default)"
                if (![string]::IsNullOrWhiteSpace($v)) {
                    $candidates.Add($v.Trim('"', ' '))
                }
            } catch {}
        }
    }

    foreach ($c in $candidates) {
        if (![string]::IsNullOrWhiteSpace($c) -and (Test-Path $c -PathType Leaf)) {
            return $c
        }
    }
    return $null
}

$browserExe = Find-ChromiumAppBrowser
$profileDir = Join-Path $env:LOCALAPPDATA "KalptenKaleme\EdgeAppProfile"
if (!(Test-Path $profileDir)) {
    try { New-Item -ItemType Directory -Path $profileDir -Force | Out-Null } catch {}
}

$antiSyncFlags = "--no-first-run --no-default-browser-check --disable-sync --disable-features=msHub,msEdgeSidebarV2,msEdgeHub,Translate,msEdgeAutoSignIn,msEdgeFirstRunExperience,msEdgeFreV2,msEdgeSyncNotice,msEdgeShowFirstRunNotification,msEdgeSignInOptIn,msEdgeFrePromo,msEdgeWelcomePageExperience,msEdgeStartupBoost"

function Launch-DesktopAppWindow([string]$TargetUrl, [switch]$AllowFileAccess) {
    if ($browserExe) {
        $extra = if ($AllowFileAccess) { " --allow-file-access-from-files" } else { "" }
        $argsStr = "--app=`"$TargetUrl`" --user-data-dir=`"$profileDir`"$extra $antiSyncFlags --window-size=1360,860"
        Start-Process -FilePath $browserExe -ArgumentList $argsStr
    } else {
        Start-Process $TargetUrl
    }
}

# If a file was passed via CLI ("Open With"), record its absolute path
$resolvedCliFile = $null
if (![string]::IsNullOrWhiteSpace($FilePath) -and (Test-Path $FilePath -PathType Leaf)) {
    try {
        $resolvedCliFile = (Resolve-Path $FilePath).Path
        [System.IO.File]::WriteAllText($openFileRecord, $resolvedCliFile, [System.Text.Encoding]::UTF8)
    } catch {}
}

# Test if server is already active on default or fallback ports
$isAlreadyListening = $false
$activeBaseUrl = "http://localhost:$port"
foreach ($cp in $candidatePorts) {
    foreach ($ch in @("localhost", "127.0.0.1")) {
        $probeUrl = "http://${ch}:${cp}/api/heartbeat"
        try {
            $testReq = [System.Net.WebRequest]::Create($probeUrl)
            $testReq.Timeout = 450
            $testResp = $testReq.GetResponse()
            $testResp.Close()
            $isAlreadyListening = $true
            $activeBaseUrl = "http://${ch}:${cp}"
            break
        } catch {}
    }
    if ($isAlreadyListening) { break }
}

if ($isAlreadyListening) {
    if ($resolvedCliFile) {
        try {
            $fBytes = [System.Text.Encoding]::UTF8.GetBytes($resolvedCliFile)
            $postReq = [System.Net.WebRequest]::Create("$activeBaseUrl/api/open-specific-file")
            $postReq.Method = "POST"
            $postReq.ContentType = "text/plain; charset=utf-8"
            $postReq.Timeout = 1000
            $postReq.ContentLength = $fBytes.Length
            $st = $postReq.GetRequestStream()
            $st.Write($fBytes, 0, $fBytes.Length)
            $st.Close()
            $postResp = $postReq.GetResponse()
            $postResp.Close()
        } catch {}
    }

    # If called as Daemon, do nothing and exit cleanly
    if (!$Daemon) {
        $broughtToFront = $false
        try {
            $wsh = New-Object -ComObject WScript.Shell
            foreach ($p in (Get-Process -ErrorAction SilentlyContinue)) {
                if ($p.MainWindowHandle -ne 0 -and $p.MainWindowTitle -like "*Kalpten Kaleme*") {
                    if ($wsh.AppActivate($p.Id)) {
                        $broughtToFront = $true
                        break
                    }
                }
            }
        } catch {}

        if (-not $broughtToFront) {
            Launch-DesktopAppWindow "$activeBaseUrl/index.html"
        }
    }
    exit
}

# Start HTTP Listener cleanly across localhost and 127.0.0.1 fallback
$listener = $null
$boundBaseUrl = $null
foreach ($cp in $candidatePorts) {
    # 1. Try dual localhost + 127.0.0.1 binding first
    try {
        $l = New-Object System.Net.HttpListener
        $l.Prefixes.Add("http://localhost:$cp/")
        $l.Prefixes.Add("http://127.0.0.1:$cp/")
        $l.Start()
        $listener = $l
        $port = $cp
        $boundBaseUrl = "http://localhost:$cp"
        break
    } catch {
        try { if ($l) { $l.Close() } } catch {}
    }

    # 2. Retry binding single loopback address in case URLACL restricts dual prefix
    foreach ($ch in @("127.0.0.1", "localhost")) {
        try {
            $l2 = New-Object System.Net.HttpListener
            $l2.Prefixes.Add("http://${ch}:${cp}/")
            $l2.Start()
            $listener = $l2
            $port = $cp
            $boundBaseUrl = "http://${ch}:${cp}"
            break
        } catch {
            try { if ($l2) { $l2.Close() } } catch {}
        }
    }
    if ($listener) { break }
}

if (-not $listener) {
    $fileUrl = "file:///" + $rootDir.Replace('\', '/') + "/index.html"
    if (!$Daemon) {
        Launch-DesktopAppWindow $fileUrl -AllowFileAccess
    }
    exit
}

$appUrl = "$boundBaseUrl/index.html"

# Launch Browser in App Mode if not running as background daemon
if (!$Daemon) {
    Launch-DesktopAppWindow $appUrl
}

function Get-SyncFolder {
    $cfgPath = Join-Path $rootDir "cloud_sync_config.txt"
    if (Test-Path $cfgPath) {
        $custom = [System.IO.File]::ReadAllText($cfgPath, [System.Text.Encoding]::UTF8).Trim()
        if (![string]::IsNullOrWhiteSpace($custom) -and (Test-Path $custom)) {
            return $custom
        }
    }

    # 1. Search all common Google Drive & OneDrive paths on Windows
    $cloudCandidates = @(
        "G:\My Drive\Kalpten Kaleme",
        "G:\Drive'ım\Kalpten Kaleme",
        "G:\Kalpten Kaleme",
        (Join-Path $env:UserProfile "Google Drive\My Drive\Kalpten Kaleme"),
        (Join-Path $env:UserProfile "Google Drive\Drive'ım\Kalpten Kaleme"),
        (Join-Path $env:UserProfile "Google Drive\Kalpten Kaleme"),
        (Join-Path $env:UserProfile "GoogleDrive\Kalpten Kaleme"),
        (if ($env:OneDrive) { Join-Path $env:OneDrive "Kalpten Kaleme" }),
        (if ($env:OneDriveConsumer) { Join-Path $env:OneDriveConsumer "Kalpten Kaleme" }),
        (Join-Path $env:UserProfile "OneDrive\Kalpten Kaleme")
    )

    foreach ($cand in $cloudCandidates) {
        if ([string]::IsNullOrWhiteSpace($cand)) { continue }
        $parent = Split-Path $cand -Parent
        if (![string]::IsNullOrWhiteSpace($parent) -and (Test-Path $parent)) {
            return $cand
        }
    }

    # 2. Local Fallback: Standard MyDocuments directory (clean, safe, no forced OneDrive)
    $docs = [Environment]::GetFolderPath("MyDocuments")
    return (Join-Path $docs "Kalpten Kaleme")
}

function Get-CloudProvider($folder) {
    if ($folder -like "*Google Drive*" -or $folder -like "*GoogleDrive*" -or $folder -like "G:\*") { return "gdrive" }
    if ($folder -like "*OneDrive*") { return "onedrive" }
    return "local"
}

function Invoke-WinFormsStaDialog([string]$ScriptText, $ArgValue) {
    if ([System.Threading.Thread]::CurrentThread.GetApartmentState() -eq [System.Threading.ApartmentState]::STA) {
        $sb = [scriptblock]::Create($ScriptText)
        return (& $sb $ArgValue)
    }
    $rs = [runspacefactory]::CreateRunspace()
    $rs.ApartmentState = [System.Threading.ApartmentState]::STA
    $rs.ThreadOptions = "ReuseThread"
    $rs.Open()
    $ps = $null
    try {
        $ps = [System.Management.Automation.PowerShell]::Create()
        $ps.Runspace = $rs
        [void]$ps.AddScript($ScriptText).AddArgument($ArgValue)
        return $ps.Invoke()
    } finally {
        if ($ps) { $ps.Dispose() }
        $rs.Close()
        $rs.Dispose()
    }
}

# Robust Request Loop with Automatic Lifecycle & Self-Termination on Exit
$hasEverConnected = $false
$startupGraceSeconds = 90
$startupTime = [DateTime]::UtcNow
$lastActiveTime = [DateTime]::UtcNow

while ($listener.IsListening) {
    try {
        $contextTask = $listener.GetContextAsync()
        while (-not $contextTask.AsyncWaitHandle.WaitOne(1000)) {
            if (-not $script:allowAutoExit) {
                # In Daemon/CI mode, do not self-terminate on silence
                continue
            }
            $now = [DateTime]::UtcNow
            if ($hasEverConnected) {
                # Browser connected previously. If no heartbeat or request for 120s, the window was closed!
                if (($now - $lastActiveTime).TotalSeconds -ge 120) {
                    try { $listener.Stop() } catch {}
                    exit
                }
            } else {
                # Startup grace period: allow up to 90s for the initial page load
                if (($now - $startupTime).TotalSeconds -ge $startupGraceSeconds) {
                    try { $listener.Stop() } catch {}
                    exit
                }
            }
        }
        $context = $contextTask.Result
        $hasEverConnected = $true
        $lastActiveTime = [DateTime]::UtcNow

        $request = $context.Request
        $response = $context.Response

        $relPath = $request.Url.LocalPath.TrimStart('/')

        # ====================================================================
        # API 0: /api/heartbeat, /api/ping, /api/detach-daemon, /api/exit
        # ====================================================================
        if ($relPath -eq "api/detach-daemon") {
            $script:allowAutoExit = $true
            $response.ContentType = "application/json; charset=utf-8"
            $response.AddHeader("Access-Control-Allow-Origin", "*")
            $bytes = [System.Text.Encoding]::UTF8.GetBytes('{"ok":true}')
            $response.OutputStream.Write($bytes, 0, $bytes.Length)
            $response.Close()
            continue
        }

        if ($relPath -eq "api/exit") {
            $forceShutdown = ($request.QueryString["shutdown"] -eq "1")
            try {
                $response.ContentType = "application/json; charset=utf-8"
                $response.AddHeader("Access-Control-Allow-Origin", "*")
                $bytes = [System.Text.Encoding]::UTF8.GetBytes('{"ok":true}')
                $response.OutputStream.Write($bytes, 0, $bytes.Length)
                $response.OutputStream.Flush()
                $response.Close()
            } catch {}
            if ($script:allowAutoExit -or $forceShutdown) {
                Start-Sleep -Milliseconds 150
                try { $listener.Stop() } catch {}
                exit
            }
            continue
        }

        if ($relPath -eq "api/heartbeat" -or $relPath -eq "api/ping") {
            $response.ContentType = "application/json; charset=utf-8"
            $response.AddHeader("Access-Control-Allow-Origin", "*")
            $bytes = [System.Text.Encoding]::UTF8.GetBytes('{"ok":true}')
            $response.OutputStream.Write($bytes, 0, $bytes.Length)
            $response.Close()
            continue
        }

        # ====================================================================
        # API 1: /api/opened-file-info (Check if a file was passed to open)
        # ====================================================================
        if ($relPath -eq "api/opened-file-info") {
            $response.ContentType = "application/json; charset=utf-8"
            $response.AddHeader("Access-Control-Allow-Origin", "*")

            if (Test-Path $openFileRecord) {
                $targetFile = [System.IO.File]::ReadAllText($openFileRecord, [System.Text.Encoding]::UTF8).Trim()
                if (![string]::IsNullOrWhiteSpace($targetFile) -and (Test-Path $targetFile)) {
                    $fullPath = [System.IO.Path]::GetFullPath($targetFile)
                    $fileName = [System.IO.Path]::GetFileName($fullPath)
                    $ext = [System.IO.Path]::GetExtension($fullPath).ToLower().TrimStart('.')
                    $jsonObj = @{ hasFile = $true; filename = $fileName; ext = $ext; path = $fullPath }
                    $json = $jsonObj | ConvertTo-Json -Compress
                    $bytes = [System.Text.Encoding]::UTF8.GetBytes($json)
                    $response.OutputStream.Write($bytes, 0, $bytes.Length)
                    $response.Close()
                    continue
                }
            }

            $emptyBytes = [System.Text.Encoding]::UTF8.GetBytes('{"hasFile":false}')
            $response.OutputStream.Write($emptyBytes, 0, $emptyBytes.Length)
            $response.Close()
            continue
        }

        if ($relPath -eq "api/window-title" -and $request.HttpMethod -eq "POST") {
            $response.ContentType = "application/json; charset=utf-8"
            $response.AddHeader("Access-Control-Allow-Origin", "*")
            $bytes = [System.Text.Encoding]::UTF8.GetBytes('{"success":true}')
            $response.OutputStream.Write($bytes, 0, $bytes.Length)
            $response.Close()
            continue
        }

        if ($relPath -eq "api/save-to-path" -and $request.HttpMethod -eq "POST") {
            $targetPath = $request.QueryString["path"]
            $savedOk = $false
            $savedFull = ""
            $savedFn = ""
            if (![string]::IsNullOrWhiteSpace($targetPath)) {
                try {
                    $savedFull = [System.IO.Path]::GetFullPath($targetPath)
                    $savedFn = [System.IO.Path]::GetFileName($savedFull)
                    $dir = [System.IO.Path]::GetDirectoryName($savedFull)
                    if (![string]::IsNullOrWhiteSpace($dir) -and !(Test-Path $dir)) {
                        [System.IO.Directory]::CreateDirectory($dir) | Out-Null
                    }
                    $fs = New-Object System.IO.FileStream($savedFull, [System.IO.FileMode]::Create, [System.IO.FileAccess]::Write)
                    $request.InputStream.CopyTo($fs)
                    $fs.Close()
                    $savedOk = $true
                } catch {}
            }
            $jsonObj = @{ success = $savedOk; path = $savedFull; filename = $savedFn }
            $json = $jsonObj | ConvertTo-Json -Compress
            $response.ContentType = "application/json; charset=utf-8"
            $response.AddHeader("Access-Control-Allow-Origin", "*")
            $bytes = [System.Text.Encoding]::UTF8.GetBytes($json)
            $response.OutputStream.Write($bytes, 0, $bytes.Length)
            $response.Close()
            continue
        }

        if ($relPath -eq "api/native-open-dialog" -and $request.HttpMethod -eq "POST") {
            $mode = "all"
            try {
                $reader = New-Object System.IO.StreamReader($request.InputStream, [System.Text.Encoding]::UTF8)
                $bodyText = $reader.ReadToEnd()
                $reader.Close()
                if ($bodyText -match '"pdf"') { $mode = "pdf" }
                elseif ($bodyText -match '"ppt"') { $mode = "ppt" }
                elseif ($bodyText -match '"word"') { $mode = "word" }
            } catch {}

            $openScript = @'
param($dialogMode)
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
$owner = New-Object System.Windows.Forms.Form
$owner.TopMost = $true
$owner.StartPosition = [System.Windows.Forms.FormStartPosition]::Manual
$owner.Location = New-Object System.Drawing.Point(-32000, -32000)
$owner.Size = New-Object System.Drawing.Size(1, 1)
$owner.ShowInTaskbar = $false
$ofd = New-Object System.Windows.Forms.OpenFileDialog
$ofd.Title = "Kalpten Kaleme — Belge Aç"
if ($dialogMode -eq "pdf") {
    $ofd.Filter = "PDF Belgeleri (*.pdf)|*.pdf|Tüm Desteklenen Belgeler|*.docx;*.doc;*.pdf;*.pptx;*.ppt;*.txt;*.md;*.html;*.json"
} elseif ($dialogMode -eq "ppt") {
    $ofd.Filter = "Sunum Dosyaları (*.pptx;*.ppt;*.json)|*.pptx;*.ppt;*.json|Tüm Desteklenen Belgeler|*.docx;*.doc;*.pdf;*.pptx;*.ppt;*.txt;*.md;*.html;*.json"
} elseif ($dialogMode -eq "word") {
    $ofd.Filter = "Word & Yazı Belgeleri (*.docx;*.doc;*.txt;*.md;*.html)|*.docx;*.doc;*.txt;*.md;*.html|Tüm Desteklenen Belgeler|*.docx;*.doc;*.pdf;*.pptx;*.ppt;*.txt;*.md;*.html;*.json"
} else {
    $ofd.Filter = "Tüm Desteklenen Belgeler|*.docx;*.doc;*.pdf;*.pptx;*.ppt;*.txt;*.md;*.html;*.json"
}
try {
    $dr = $ofd.ShowDialog($owner)
    if ($dr -eq [System.Windows.Forms.DialogResult]::OK -and ![string]::IsNullOrWhiteSpace($ofd.FileName)) {
        return [System.IO.Path]::GetFullPath($ofd.FileName)
    }
    return $null
} finally {
    $ofd.Dispose()
    $owner.Dispose()
}
'@
            $selectedRaw = Invoke-WinFormsStaDialog $openScript $mode
            $selPath = ($selectedRaw | Select-Object -Last 1)
            if ($selPath -and ![string]::IsNullOrWhiteSpace([string]$selPath)) {
                $selPath = [string]$selPath
                [System.IO.File]::WriteAllText($openFileRecord, $selPath, [System.Text.Encoding]::UTF8)
                $jsonObj = @{ success = $true; path = $selPath; filename = [System.IO.Path]::GetFileName($selPath) }
            } else {
                $jsonObj = @{ success = $false; cancelled = $true }
            }
            $json = $jsonObj | ConvertTo-Json -Compress
            $response.ContentType = "application/json; charset=utf-8"
            $response.AddHeader("Access-Control-Allow-Origin", "*")
            $bytes = [System.Text.Encoding]::UTF8.GetBytes($json)
            $response.OutputStream.Write($bytes, 0, $bytes.Length)
            $response.Close()
            continue
        }

        if ($relPath -eq "api/native-save-dialog" -and $request.HttpMethod -eq "POST") {
            $suggestedName = $request.QueryString["filename"]
            if ([string]::IsNullOrWhiteSpace($suggestedName)) { $suggestedName = "Yeni Yazı.docx" }
            $suggestedName = [System.IO.Path]::GetFileName($suggestedName)
            $ms = New-Object System.IO.MemoryStream
            $request.InputStream.CopyTo($ms)
            $fileData = $ms.ToArray()
            $ms.Close()

            $saveScript = @'
param($sugName)
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
$owner = New-Object System.Windows.Forms.Form
$owner.TopMost = $true
$owner.StartPosition = [System.Windows.Forms.FormStartPosition]::Manual
$owner.Location = New-Object System.Drawing.Point(-32000, -32000)
$owner.Size = New-Object System.Drawing.Size(1, 1)
$owner.ShowInTaskbar = $false
$sfd = New-Object System.Windows.Forms.SaveFileDialog
$sfd.Title = "Kalpten Kaleme — Farklı Kaydet"
$sfd.FileName = $sugName
$ext = [System.IO.Path]::GetExtension($sugName).ToLower()
if ($ext -eq ".pdf") {
    $sfd.DefaultExt = "pdf"
    $sfd.Filter = "PDF Belgesi (*.pdf)|*.pdf|Tüm Dosyalar (*.*)|*.*"
} elseif ($ext -eq ".pptx") {
    $sfd.DefaultExt = "pptx"
    $sfd.Filter = "PowerPoint Sunumu (*.pptx)|*.pptx|Tüm Dosyalar (*.*)|*.*"
} elseif ($ext -eq ".json") {
    $sfd.DefaultExt = "json"
    $sfd.Filter = "Sunum Projesi (*.json)|*.json|Tüm Dosyalar (*.*)|*.*"
} else {
    $sfd.DefaultExt = "docx"
    $sfd.Filter = "Microsoft Word Belgesi (*.docx)|*.docx|Metin Dosyası (*.txt)|*.txt|HTML Belgesi (*.html)|*.html"
}
try {
    $dr = $sfd.ShowDialog($owner)
    if ($dr -eq [System.Windows.Forms.DialogResult]::OK -and ![string]::IsNullOrWhiteSpace($sfd.FileName)) {
        return [System.IO.Path]::GetFullPath($sfd.FileName)
    }
    return $null
} finally {
    $sfd.Dispose()
    $owner.Dispose()
}
'@
            $chosenRaw = Invoke-WinFormsStaDialog $saveScript $suggestedName
            $chosenPath = ($chosenRaw | Select-Object -Last 1)
            if ($chosenPath -and ![string]::IsNullOrWhiteSpace([string]$chosenPath)) {
                $chosenPath = [string]$chosenPath
                [System.IO.File]::WriteAllBytes($chosenPath, $fileData)
                $jsonObj = @{ success = $true; path = $chosenPath; filename = [System.IO.Path]::GetFileName($chosenPath) }
            } else {
                $jsonObj = @{ success = $false; cancelled = $true }
            }
            $json = $jsonObj | ConvertTo-Json -Compress
            $response.ContentType = "application/json; charset=utf-8"
            $response.AddHeader("Access-Control-Allow-Origin", "*")
            $bytes = [System.Text.Encoding]::UTF8.GetBytes($json)
            $response.OutputStream.Write($bytes, 0, $bytes.Length)
            $response.Close()
            continue
        }

        # ====================================================================
        # API 2: /api/opened-file-data (Serve the raw binary file content)
        # ====================================================================
        if ($relPath -eq "api/opened-file-data") {
            $response.AddHeader("Access-Control-Allow-Origin", "*")

            if (Test-Path $openFileRecord) {
                $targetFile = [System.IO.File]::ReadAllText($openFileRecord, [System.Text.Encoding]::UTF8).Trim()
                if (![string]::IsNullOrWhiteSpace($targetFile) -and (Test-Path $targetFile)) {
                    $fileBytes = [System.IO.File]::ReadAllBytes($targetFile)
                    $response.ContentType = "application/octet-stream"
                    $response.ContentLength64 = $fileBytes.Length
                    $response.OutputStream.Write($fileBytes, 0, $fileBytes.Length)
                    $response.Close()

                    Remove-Item $openFileRecord -Force -ErrorAction SilentlyContinue
                    continue
                }
            }

            $response.StatusCode = 404
            $response.Close()
            continue
        }

        # ====================================================================
        # API 3: /api/save-document (Save DOCX / PDF / JSON directly to disk)
        # ====================================================================
        if ($relPath -eq "api/save-document" -and $request.HttpMethod -eq "POST") {
            $filename = $request.QueryString["filename"]
            if ([string]::IsNullOrWhiteSpace($filename)) { $filename = "Yeni Yazı.docx" }
            $filename = [System.IO.Path]::GetFileName($filename)

            $targetFolder = Get-SyncFolder
            if (!(Test-Path $targetFolder)) {
                [System.IO.Directory]::CreateDirectory($targetFolder) | Out-Null
            }
            $savePath = Join-Path $targetFolder $filename

            $fs = New-Object System.IO.FileStream($savePath, [System.IO.FileMode]::Create, [System.IO.FileAccess]::Write)
            $request.InputStream.CopyTo($fs)
            $fs.Close()

            $timeStr = (Get-Date).ToString("HH:mm")
            $provider = Get-CloudProvider $targetFolder
            $isGDrive = ($provider -eq "gdrive")
            $isCloud = ($provider -ne "local")

            $jsonObj = @{
                success = $true
                path = $savePath
                filename = $filename
                time = $timeStr
                isGoogleDrive = $isGDrive
                isCloudSync = $isCloud
                cloudProvider = $provider
            }
            $json = $jsonObj | ConvertTo-Json -Compress
            $response.ContentType = "application/json; charset=utf-8"
            $response.AddHeader("Access-Control-Allow-Origin", "*")
            $bytes = [System.Text.Encoding]::UTF8.GetBytes($json)
            $response.OutputStream.Write($bytes, 0, $bytes.Length)
            $response.Close()
            continue
        }

        # ====================================================================
        # API 4: /api/drive-status (Get current folder and cloud sync status)
        # ====================================================================
        if ($relPath -eq "api/drive-status") {
            $folder = Get-SyncFolder
            $provider = Get-CloudProvider $folder
            $isGDrive = ($provider -eq "gdrive")
            $isCloud = ($provider -ne "local")
            $exists = Test-Path $folder

            $jsonObj = @{
                syncFolder = $folder
                isGoogleDrive = $isGDrive
                isCloudSync = $isCloud
                cloudProvider = $provider
                exists = $exists
            }
            $json = $jsonObj | ConvertTo-Json -Compress
            $response.ContentType = "application/json; charset=utf-8"
            $response.AddHeader("Access-Control-Allow-Origin", "*")
            $bytes = [System.Text.Encoding]::UTF8.GetBytes($json)
            $response.OutputStream.Write($bytes, 0, $bytes.Length)
            $response.Close()
            continue
        }

        # ====================================================================
        # API 5: /api/drive-files (List documents in sync folder)
        # ====================================================================
        if ($relPath -eq "api/drive-files" -or $relPath -eq "api/list-documents" -or $relPath -eq "api/list-cloud-files") {
            $folder = Get-SyncFolder
            $fileList = @()
            if (Test-Path $folder) {
                $files = Get-ChildItem -Path $folder -File | Where-Object { $_.Extension -match "^\.(docx|doc|txt|md|html|pdf|pptx|ppt|json)$" } | Sort-Object LastWriteTime -Descending
                foreach ($f in $files) {
                    $sizeStr = if ($f.Length -gt 1MB) { "{0:N1} MB" -f ($f.Length / 1MB) } else { "{0} KB" -f [Math]::Max(1, [Math]::Round($f.Length / 1KB)) }
                    $fileList += @{
                        name = $f.Name
                        path = $f.FullName
                        size = $sizeStr
                        date = $f.LastWriteTime.ToString("dd.MM.yyyy HH:mm")
                        ext = $f.Extension.TrimStart('.').ToLower()
                    }
                }
            }
            $json = ConvertTo-Json -InputObject @($fileList) -Compress
            if (!$json -or $fileList.Count -eq 0) { $json = "[]" }
            elseif ($fileList.Count -eq 1 -and !$json.StartsWith("[")) { $json = "[$json]" }
            $response.ContentType = "application/json; charset=utf-8"
            $response.AddHeader("Access-Control-Allow-Origin", "*")
            $bytes = [System.Text.Encoding]::UTF8.GetBytes($json)
            $response.OutputStream.Write($bytes, 0, $bytes.Length)
            $response.Close()
            continue
        }

        # ====================================================================
        # API 6: /api/open-sync-folder (Open Explorer at sync folder)
        # ====================================================================
        if ($relPath -eq "api/open-sync-folder") {
            $folder = Get-SyncFolder
            if (Test-Path $folder) {
                Start-Process "explorer.exe" -ArgumentList "`"$folder`""
            }
            $response.ContentType = "application/json; charset=utf-8"
            $response.AddHeader("Access-Control-Allow-Origin", "*")
            $bytes = [System.Text.Encoding]::UTF8.GetBytes('{"success":true}')
            $response.OutputStream.Write($bytes, 0, $bytes.Length)
            $response.Close()
            continue
        }

        # ====================================================================
        # API 7: /api/open-file-by-path (Stream requested document bytes)
        # ====================================================================
        if ($relPath -eq "api/open-file-by-path") {
            $p = $request.QueryString["path"]
            if (![string]::IsNullOrWhiteSpace($p) -and (Test-Path $p)) {
                $bytes = [System.IO.File]::ReadAllBytes($p)
                $response.ContentType = "application/octet-stream"
                $response.ContentLength64 = $bytes.Length
                $response.AddHeader("Access-Control-Allow-Origin", "*")
                $response.OutputStream.Write($bytes, 0, $bytes.Length)
                $response.Close()
                continue
            }
            $response.StatusCode = 404
            $response.Close()
            continue
        }

        # ====================================================================
        # API 8: /api/open-specific-file (Queue file to be opened in app)
        # ====================================================================
        if (($relPath -eq "api/open-specific-file" -or $relPath -eq "api/open-file") -and $request.HttpMethod -eq "POST") {
            $reader = New-Object System.IO.StreamReader($request.InputStream, [System.Text.Encoding]::UTF8)
            $filePath = $reader.ReadToEnd().Trim()
            $reader.Close()
            $foundPath = $null
            if (![string]::IsNullOrWhiteSpace($filePath)) {
                if (Test-Path $filePath -PathType Leaf) {
                    $foundPath = (Resolve-Path $filePath).Path
                } else {
                    $syncCandidate = Join-Path (Get-SyncFolder) ([System.IO.Path]::GetFileName($filePath))
                    if (Test-Path $syncCandidate -PathType Leaf) {
                        $foundPath = (Resolve-Path $syncCandidate).Path
                    }
                }
            }
            if ($foundPath) {
                [System.IO.File]::WriteAllText($openFileRecord, $foundPath, [System.Text.Encoding]::UTF8)
                $respJson = '{"success":true}'
            } else {
                $respJson = '{"success":false}'
            }
            $response.ContentType = "application/json; charset=utf-8"
            $response.AddHeader("Access-Control-Allow-Origin", "*")
            $bytes = [System.Text.Encoding]::UTF8.GetBytes($respJson)
            $response.OutputStream.Write($bytes, 0, $bytes.Length)
            $response.Close()
            continue
        }

        # ====================================================================
        # API 8B: /api/delete-file (Delete file from sync folder)
        # ====================================================================
        if ($relPath -eq "api/delete-file" -and $request.HttpMethod -eq "POST") {
            $reader = New-Object System.IO.StreamReader($request.InputStream, [System.Text.Encoding]::UTF8)
            $filePath = $reader.ReadToEnd().Trim()
            $reader.Close()
            $deleted = $false
            if (![string]::IsNullOrWhiteSpace($filePath)) {
                $targetToDelete = $null
                if (Test-Path $filePath -PathType Leaf) {
                    $targetToDelete = $filePath
                } else {
                    $syncCandidate = Join-Path (Get-SyncFolder) ([System.IO.Path]::GetFileName($filePath))
                    if (Test-Path $syncCandidate -PathType Leaf) {
                        $targetToDelete = $syncCandidate
                    }
                }
                if ($targetToDelete) {
                    try {
                        Remove-Item -LiteralPath $targetToDelete -Force -ErrorAction Stop
                        $deleted = $true
                    } catch {}
                }
            }
            $respJson = if ($deleted) { '{"success":true}' } else { '{"success":false}' }
            $response.ContentType = "application/json; charset=utf-8"
            $response.AddHeader("Access-Control-Allow-Origin", "*")
            $bytes = [System.Text.Encoding]::UTF8.GetBytes($respJson)
            $response.OutputStream.Write($bytes, 0, $bytes.Length)
            $response.Close()
            continue
        }

        # ====================================================================
        # API 9: /api/select-sync-folder (Pick custom sync / drive folder)
        # ====================================================================
        if ($relPath -eq "api/select-sync-folder") {
            try {
                $folderScript = @'
param($unused)
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
$owner = New-Object System.Windows.Forms.Form
$owner.TopMost = $true
$owner.StartPosition = [System.Windows.Forms.FormStartPosition]::Manual
$owner.Location = New-Object System.Drawing.Point(-32000, -32000)
$owner.Size = New-Object System.Drawing.Size(1, 1)
$owner.ShowInTaskbar = $false
$fbd = New-Object System.Windows.Forms.FolderBrowserDialog
$fbd.Description = "Kalpten Kaleme Belgelerinizin Eşitleneceği Klasörü Seçin (Google Drive / OneDrive / Belgeler)"
$fbd.ShowNewFolderButton = $true
try {
    $dialogResult = $fbd.ShowDialog($owner)
    if ($dialogResult -eq [System.Windows.Forms.DialogResult]::OK -and !([string]::IsNullOrWhiteSpace($fbd.SelectedPath))) {
        return $fbd.SelectedPath
    }
    return $null
} finally {
    $fbd.Dispose()
    $owner.Dispose()
}
'@
                $selectedFolderRaw = Invoke-WinFormsStaDialog $folderScript $null
                $selectedFolder = ($selectedFolderRaw | Select-Object -Last 1)
                if ($selectedFolder -and !([string]::IsNullOrWhiteSpace([string]$selectedFolder))) {
                    [System.IO.File]::WriteAllText((Join-Path $rootDir "cloud_sync_config.txt"), [string]$selectedFolder, [System.Text.Encoding]::UTF8)
                }
            } catch {}

            $curFolder = Get-SyncFolder
            $provider = Get-CloudProvider $curFolder
            $jsonObj = @{
                syncFolder = $curFolder
                isGoogleDrive = ($provider -eq "gdrive")
                isCloudSync = ($provider -ne "local")
                cloudProvider = $provider
            }
            $json = $jsonObj | ConvertTo-Json -Compress
            $response.ContentType = "application/json; charset=utf-8"
            $response.AddHeader("Access-Control-Allow-Origin", "*")
            $bytes = [System.Text.Encoding]::UTF8.GetBytes($json)
            $response.OutputStream.Write($bytes, 0, $bytes.Length)
            $response.Close()
            continue
        }

        # ====================================================================
        # Static File Serving
        # ====================================================================
        if ([string]::IsNullOrWhiteSpace($relPath)) {
            $relPath = "index.html"
        }

        $filePath = Join-Path $rootDir $relPath

        if (Test-Path $filePath -PathType Leaf) {
            $ext = [System.IO.Path]::GetExtension($filePath).ToLower()
            $mime = "application/octet-stream"
            if ($mimeTypes.ContainsKey($ext)) {
                $mime = $mimeTypes[$ext]
            }

            $bytes = [System.IO.File]::ReadAllBytes($filePath)
            $response.ContentType = $mime
            $response.ContentLength64 = $bytes.Length
            $response.AddHeader("Access-Control-Allow-Origin", "*")
            $response.OutputStream.Write($bytes, 0, $bytes.Length)
        } else {
            $response.StatusCode = 404
            $buffer = [System.Text.Encoding]::UTF8.GetBytes("404 Not Found")
            $response.OutputStream.Write($buffer, 0, $buffer.Length)
        }
        $response.Close()
    } catch [System.Net.HttpListenerException] {
        if ($listener.IsListening) {
            continue
        } else {
            break
        }
    } catch {
        continue
    }
}
